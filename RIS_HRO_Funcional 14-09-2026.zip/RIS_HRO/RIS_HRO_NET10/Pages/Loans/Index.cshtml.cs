using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RIS_HRO.Models;
using RIS_HRO.Repositories;

namespace RIS_HRO.Pages.Loans;

[Authorize(Roles = "ADMINISTRADOR,USUARIO_INFORMES,USUARIO_CITAS")]
public sealed class IndexModel : PageModel
{
    private readonly LoanRepository _loans;

    public IndexModel(LoanRepository loans)
    {
        _loans = loans;
    }

    public List<ActiveLoanRow> Rows { get; private set; } = [];

    public async Task OnGetAsync(CancellationToken ct)
    {
        Rows = await _loans.ListActiveLoansAsync(ct);
    }
}
